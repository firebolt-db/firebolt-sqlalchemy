token_url = "https://api.app.firebolt.io/auth/v1/login"
token_header = {"Content-Type": "application/json;charset=UTF-8"}
refresh_url = "https://api.app.firebolt.io/auth/v1/refresh"
query_engine_url = 'https://api.app.firebolt.io/core/v1/account/engines:getURLByDatabaseName'
engine_id_url = "https://api.app.firebolt.io/core/v1/account/engines:getIdbyName"
engine_start_url = 'https://api.app.firebolt.io/core/v1/account/engines/'
default_engine_name = 'sigmoid-alchemy-analytics'